/* Esercizio SQL, creazione database per azienda distributrice di giocattoli, il database a livello 
 * concettuale è semplificato */

create database if not exists ToysGroup;

use ToysGroup;

create table Product(
	ProductID int not null PRIMARY KEY,
 	ProductName varchar(256) not null,
 	ProductCategoryID int,
	ProductSubCategoryID int,
	StockLevel int not null,
	Color varchar(30),
	ProductWeightGr decimal(8,2),
	ProductSizeVolM3 decimal(5,2),
	ProductCost decimal(8,2) not null, 
	ListPrice decimal(8,2) not null,
	constraint FK_product_category_product FOREIGN KEY (ProductCategoryID) references ProductCategory(ProductCategoryID),
	constraint FK_product_sub_category FOREIGN KEY (ProductSubCategoryID) references ProductSubCategory (ProductSubCategoryID)
	);
-- ProductTotalCost decimal(8,2) not null,
-- eliminazione TotalProductCost
alter table Product
drop column ProductTotalCost;



	
create table ProductCategory(
	ProductCategoryID int not null PRIMARY KEY,
	ProductCategoryName varchar(255) not null
	);
-- Errore nell'inserimento del nome
alter table ProductCategory 
rename column ProuctCategoryID to ProductCategoryID;
	
create table ProductSubCategory(
	ProductSubCategoryID int not null PRIMARY KEY,
	ProductSubCategoryName varchar(255) not null,
	ProductCategoryID int,
	constraint FK_product_Category FOREIGN KEY (ProductCategoryID) 
	references ProductCategory (ProductCategoryID)
	);

create table Region(
	CountryID int not null PRIMARY KEY,
	CountryName varchar(100) not null,
	RegionMacroArea varchar(100) 
	);
	
create table City(
	CityID int not null auto_increment PRIMARY KEY,
	CityName varchar(100) not null,
	RegionName varchar(100), 
	ProvinceCode Char(5),
	ProvinceName varchar(100),
	CountryID int not null,
	constraint FK_country FOREIGN KEY (CountryID) references Region(CountryID) 
	);

create table Sales(
	SalesOrderID char(6) not null,
	SalesOrderLine int not null,
	OrderDate date not null,
	ShipDate date not null,
	ProductID int not null,
	CityID int not null,
	CountryID int not null,
	OrderQuantity int not null,
	UnitPrice decimal(8,2) not null,
	PRIMARY KEY(SalesOrderID, SalesOrderLine),
	constraint FK_product FOREIGN KEY (ProductID) references Product(ProductID),
	constraint FK_city FOREIGN KEY (CityID) references City(CityID),
	constraint FK_country_sales FOREIGN KEY (CountryID) references Region(CountryID)
 	);
 
 /* Popolamento Tabella ProductCategory*/
 
 -- Category "Dolls and Stuffed Animals"
INSERT INTO ProductCategory (ProductCategoryID, ProductCategoryName)
VALUES (1, 'Dolls and Stuffed Animals');

-- Category "Educational Toys"
INSERT INTO ProductCategory (ProductCategoryID, ProductCategoryName)
VALUES (2, 'Educational Toys');

-- Category "Building Sets and Puzzles"
INSERT INTO ProductCategory (ProductCategoryID, ProductCategoryName)
VALUES (3, 'Building Sets and Puzzles');

-- Category "Vehicles and Cars"
INSERT INTO ProductCategory (ProductCategoryID, ProductCategoryName)
VALUES (4, 'Vehicles and Cars');

-- Category "Outdoor Games"
INSERT INTO ProductCategory (ProductCategoryID, ProductCategoryName)
VALUES (5, 'Outdoor Games');


select * from ProductCategory pc
; 

 /* Popolamento Tabella ProductSubCategory*/


-- Inserimento di record per la categoria "Dolls and Stuffed Animals" (ProductCategoryID = 1)
INSERT INTO ProductSubCategory (ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID)
VALUES (1, 'Barbie Dolls', 1),
       (2, 'Teddy Bears', 1),
       (3, 'Doll Accessories', 1);

-- Inserimento di record per la categoria "Educational Toys" (ProductCategoryID = 2)
INSERT INTO ProductSubCategory (ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID)
VALUES (4, 'Building Blocks', 2),
       (5, 'Science Kits', 2),
       (6, 'Educational Board Games', 2);

-- Inserimento di record per la categoria "Building Sets and Puzzles" (ProductCategoryID = 3)
INSERT INTO ProductSubCategory (ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID)
VALUES (7, 'LEGO Sets', 3),
       (8, 'Jigsaw Puzzles', 3);

-- Inserimento di record per la categoria "Vehicles and Cars" (ProductCategoryID = 4)
INSERT INTO ProductSubCategory (ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID)
VALUES (9, 'Remote Control Cars', 4),
       (10, 'Die-cast Vehicles', 4);
      
-- Inserimento di record per la categoria "Outdoor Games" (ProductCategoryID = 5)
INSERT INTO ProductSubCategory (ProductSubCategoryID, ProductSubCategoryName, ProductCategoryID)
VALUES (11, 'Badminton Sets', 5),
       (12, 'Soccer Balls', 5);

select * from ProductSubCategory psc ;

/* Popolamento tabella Region*/

-- Inserimento di record per paesi nella regione Europa
INSERT INTO Region (CountryID, CountryName, RegionMacroArea)
VALUES (1, 'Italy', 'Europe'),
       (2, 'France', 'Europe'),
       (3, 'Germany', 'Europe'),
       (4, 'Spain', 'Europe'),
       (5, 'United Kingdom', 'Europe'),
       (6, 'Netherlands', 'Europe'),
       (7, 'Switzerland', 'Europe'),
       (8, 'Sweden', 'Europe'),
       (9, 'Norway', 'Europe'),
       (10, 'Greece', 'Europe'),
       (11, 'Portugal', 'Europe'),
       (12, 'Austria', 'Europe');

-- Inserimento di record per paesi nella regione Nord America
INSERT INTO Region (CountryID, CountryName, RegionMacroArea)
VALUES (13, 'United States', 'North America'),
       (14, 'Canada', 'North America'),
       (15, 'Mexico', 'North America');

-- Inserimento di record per paesi nella regione Asia
INSERT INTO Region (CountryID, CountryName, RegionMacroArea)
VALUES (16, 'China', 'Asia'),
       (17, 'India', 'Asia'),
       (18, 'Japan', 'Asia'),
       (19, 'South Korea', 'Asia'),
       (20, 'Singapore', 'Asia');

select * from Region r ;

/* Popolazione Tabella City */

-- Inserimento di record per città (cambiando CountryID ogni 15 record)
INSERT INTO City (CityName, RegionName, ProvinceCode, ProvinceName, CountryID)
VALUES 
    -- Italia (CountryID = 1)
    ('Rome', 'Lazio', 'RM', 'Roma', 1),
    ('Milan', 'Lombardy', 'MI', 'Milano', 1),
    ('Naples', 'Campania', 'NA', 'Napoli', 1),
    ('Turin', 'Piedmont', 'TO', 'Torino', 1),
    ('Palermo', 'Sicily', 'PA', 'Palermo', 1),
    ('Genoa', 'Liguria', 'GE', 'Genova', 1),
    ('Bologna', 'Emilia-Romagna', 'BO', 'Bologna', 1),
    ('Florence', 'Tuscany', 'FI', 'Firenze', 1),
    ('Venice', 'Veneto', 'VE', 'Venezia', 1),
    ('Verona', 'Veneto', 'VR', 'Verona', 1),
    ('Bari', 'Apulia', 'BA', 'Bari', 1),
    ('Catania', 'Sicily', 'CT', 'Catania', 1),
    ('Brescia', 'Lombardy', 'BS', 'Brescia', 1),
    ('Taranto', 'Apulia', 'TA', 'Taranto', 1),
    ('Reggio Calabria', 'Calabria', 'RC', 'Reggio Calabria', 1),
    -- Cambio a Stati Uniti (CountryID = 13)
    ('New York City', 'New York', 'NY', 'New York', 13),
    ('Los Angeles', 'California', 'CA', 'California', 13),
    ('Chicago', 'Illinois', 'IL', 'Illinois', 13),
    ('Houston', 'Texas', 'TX', 'Texas', 13),
    ('Phoenix', 'Arizona', 'AZ', 'Arizona', 13),
    ('Philadelphia', 'Pennsylvania', 'PA', 'Pennsylvania', 13),
    ('San Antonio', 'Texas', 'TX', 'Texas', 13),
    ('San Diego', 'California', 'CA', 'California', 13),
    ('Dallas', 'Texas', 'TX', 'Texas', 13),
    ('San Jose', 'California', 'CA', 'California', 13),
    ('Austin', 'Texas', 'TX', 'Texas', 13),
    ('Jacksonville', 'Florida', 'FL', 'Florida', 13),
    ('Fort Worth', 'Texas', 'TX', 'Texas', 13),
    ('Columbus', 'Ohio', 'OH', 'Ohio', 13),
    ('Charlotte', 'North Carolina', 'NC', 'North Carolina', 13),
    -- Cambio a Francia (CountryID = 2)
    ('Paris', 'Île-de-France', '75', 'Paris', 2),
    ('Marseille', 'Provence-Alpes-Côte d''Azur', '13', 'Bouches-du-Rhône', 2),
    ('Lyon', 'Auvergne-Rhône-Alpes', '69', 'Rhône', 2),
    ('Toulouse', 'Occitanie', '31', 'Haute-Garonne', 2),
    ('Nice', 'Provence-Alpes-Côte d''Azur', '06', 'Alpes-Maritimes', 2),
    ('Nantes', 'Pays de la Loire', '44', 'Loire-Atlantique', 2),
    ('Strasbourg', 'Grand Est', '67', 'Bas-Rhin', 2),
    ('Montpellier', 'Occitanie', '34', 'Hérault', 2),
    ('Bordeaux', 'Nouvelle-Aquitaine', '33', 'Gironde', 2),
    ('Lille', 'Hauts-de-France', '59', 'Nord', 2),
    ('Rennes', 'Brittany', '35', 'Ille-et-Vilaine', 2),
    ('Reims', 'Grand Est', '51', 'Marne', 2),
    ('Le Havre', 'Normandy', '76', 'Seine-Maritime', 2),
    ('Clermont-Ferrand', 'Auvergne-Rhône-Alpes', '63', 'Puy-de-Dôme', 2),
    ('Toulon', 'Provence-Alpes-Côte d''Azur', '83', 'Var', 2),
    ('Angers', 'Pays de la Loire', '49', 'Maine-et-Loire', 2),
    ('Grenoble', 'Auvergne-Rhône-Alpes', '38', 'Isère', 2),
    ('Dijon', 'Bourgogne-Franche-Comté', '21', 'Côte-d''Or', 2),
    ('Saint-Étienne', 'Auvergne-Rhône-Alpes', '42', 'Loire', 2),
    ('Nîmes', 'Occitanie', '30', 'Gard', 2),
    ('Aix-en-Provence', 'Provence-Alpes-Côte d''Azur', '13', 'Bouches-du-Rhône', 2),
    ('Saint-Denis', 'Île-de-France', '93', 'Seine-Saint-Denis', 2),
    ('Villeurbanne', 'Auvergne-Rhône-Alpes', '69', 'Rhône', 2),
    ('Le Mans', 'Pays de la Loire', '72', 'Sarthe', 2),
    ('Clermont', 'Nouvelle-Aquitaine', '40', 'Landes', 2),
    ('Tours', 'Centre-Val de Loire', '37', 'Indre-et-Loire', 2),
    ('Amiens', 'Hauts-de-France', '80', 'Somme', 2),
    ('Metz', 'Grand Est', '57', 'Moselle', 2),
    ('Besançon', 'Bourgogne-Franche-Comté', '25', 'Doubs', 2),
    ('Perpignan', 'Occitanie', '66', 'Pyrénées-Orientales', 2);

INSERT INTO City (CityName, RegionName, ProvinceCode, ProvinceName, CountryID)
VALUES 
    -- Cambio a Regno Unito (CountryID = 5)
    ('London', 'Greater London', 'LDN', 'London', 5),
    ('Manchester', 'Greater Manchester', 'MAN', 'Manchester', 5),
    ('Birmingham', 'West Midlands', 'BIR', 'Birmingham', 5),
    ('Liverpool', 'Merseyside', 'LIV', 'Liverpool', 5),
    ('Glasgow', 'Glasgow City', 'GLA', 'Glasgow', 5),
    ('Edinburgh', 'City of Edinburgh', 'EDB', 'Edinburgh', 5),
    ('Bristol', 'Bristol', 'BRS', 'Bristol', 5),
    ('Leeds', 'West Yorkshire', 'LDS', 'Leeds', 5),
    ('Sheffield', 'South Yorkshire', 'SHF', 'Sheffield', 5),
    ('Newcastle upon Tyne', 'Tyne and Wear', 'NCL', 'Newcastle upon Tyne', 5),
    ('Nottingham', 'Nottinghamshire', 'NOT', 'Nottingham', 5),
    ('Cardiff', 'Cardiff', 'CDF', 'Cardiff', 5),
    ('Belfast', 'Belfast', 'BLF', 'Belfast', 5),
    ('Leicester', 'Leicestershire', 'LEI', 'Leicester', 5),
    -- Cambio a Canada (CountryID = 14)
    ('Toronto', 'Ontario', 'ON', 'Toronto', 14),
    ('Montreal', 'Quebec', 'QC', 'Montreal', 14),
    ('Vancouver', 'British Columbia', 'BC', 'Vancouver', 14),
    ('Calgary', 'Alberta', 'AB', 'Calgary', 14),
    ('Ottawa', 'Ontario', 'ON', 'Ottawa', 14),
    ('Edmonton', 'Alberta', 'AB', 'Edmonton', 14),
    ('Winnipeg', 'Manitoba', 'MB', 'Winnipeg', 14),
    ('Quebec City', 'Quebec', 'QC', 'Quebec City', 14),
    ('Hamilton', 'Ontario', 'ON', 'Hamilton', 14),
    ('Kitchener', 'Ontario', 'ON', 'Waterloo', 14),
    ('London', 'Ontario', 'ON', 'London', 14),
    ('Victoria', 'British Columbia', 'BC', 'Victoria', 14),
    ('Halifax', 'Nova Scotia', 'NS', 'Halifax', 14),
    ('Saskatoon', 'Saskatchewan', 'SK', 'Saskatoon', 14),
    ('Regina', 'Saskatchewan', 'SK', 'Regina', 14),
    ('St. John''s', 'Newfoundland and Labrador', 'NL', 'St. John''s', 14),
    -- Cambio ad Australia (CountryID = 16)
    ('Sydney', 'New South Wales', 'NSW', 'Sydney', 16),
    ('Melbourne', 'Victoria', 'VIC', 'Melbourne', 16),
    ('Brisbane', 'Queensland', 'QLD', 'Brisbane', 16),
    ('Perth', 'Western Australia', 'WA', 'Perth', 16),
    ('Adelaide', 'South Australia', 'SA', 'Adelaide', 16),
    ('Gold Coast', 'Queensland', 'QLD', 'Gold Coast', 16),
    ('Newcastle', 'New South Wales', 'NSW', 'Newcastle', 16),
    ('Canberra', 'Australian Capital Territory', 'ACT', 'Canberra', 16),
    ('Sunshine Coast', 'Queensland', 'QLD', 'Sunshine Coast', 16),
    ('Wollongong', 'New South Wales', 'NSW', 'Wollongong', 16),
    ('Hobart', 'Tasmania', 'TAS', 'Hobart', 16),
    ('Geelong', 'Victoria', 'VIC', 'Geelong', 16),
    ('Townsville', 'Queensland', 'QLD', 'Townsville', 16),
    ('Cairns', 'Queensland', 'QLD', 'Cairns', 16),
    ('Darwin', 'Northern Territory', 'NT', 'Darwin', 16),
    ('Toowoomba', 'Queensland', 'QLD', 'Toowoomba', 16);

select * from City c ;

/* Popolamento tabella Product */

-- Inserimento di 20 record per la tabella Product
INSERT INTO Product (ProductID, ProductName, ProductCategoryID, ProductSubCategoryID, StockLevel, Color, ProductWeightGr, ProductSizeVolM3, ProductCost, ListPrice)
VALUES
    (1, 'Action Figure', 1, 1, 50, 'Red', 150, 0.3, 9.99, 19.99),
    (2, 'Dollhouse Playset', 1, 2, 30, 'Pink', 1200, 0.8, 39.99, 59.99),
    (3, 'Toy Race Car Set', 2, 3, 80, 'Blue', 300, 0.2, 12.99, 24.99),
    (4, 'Building Blocks Kit', 2, 4, 100, 'Multi-color', 600, 0.4, 19.99, 29.99),
    (5, 'Remote Control Helicopter', 3, 5, 70, 'Silver', 800, 0.5, 29.99, 49.99),
    (6, 'Art Paint Set', 4, 6, 90, 'Various', 400, 0.3, 14.99, 19.99),
    (7, 'Science Experiment Kit', 5, 7, 60, 'Green', 1000, 0.6, 24.99, 39.99),
    (8, 'Puzzle Cube', 2, 8, 40, 'White', 200, 0.1, 5.99, 9.99),
    (9, 'Musical Keyboard', 4, 9, 25, 'Black', 1500, 0.7, 69.99, 99.99),
    (10, 'Plush Stuffed Animal', 3, 10, 85, 'Brown', 300, 0.2, 12.99, 19.99);
INSERT INTO Product (ProductID, ProductName, ProductCategoryID, ProductSubCategoryID, StockLevel, Color, ProductWeightGr, ProductSizeVolM3, ProductCost, ListPrice)
VALUES
    (11, 'Wooden Train Set', 1, 3, 65, 'Brown', 700, 0.4, 24.99, 39.99);
INSERT INTO Product (ProductID, ProductName, ProductCategoryID, ProductSubCategoryID, StockLevel, Color, ProductWeightGr, ProductSizeVolM3, ProductCost, ListPrice)
VALUES
    (12, 'Dinosaur Action Figures', 1, 4, 55, 'Green', 400, 0.3, 17.99, 29.99),
    (13, 'Barbie Doll', 1, 5, 45, 'Pink', 300, 0.2, 14.99, 24.99),
    (14, 'Remote Control Boat', 2, 6, 75, 'Blue', 600, 0.4, 29.99, 49.99);
INSERT INTO Product (ProductID, ProductName, ProductCategoryID, ProductSubCategoryID, StockLevel, Color, ProductWeightGr, ProductSizeVolM3, ProductCost, ListPrice)
VALUES
    (15, 'Building Bricks Set', 2, 7, 85, 'Red', 800, 0.5, 34.99, 54.99),
    (16, 'Toy Plane Model Kit', 2, 8, 60, 'White', 350, 0.3, 19.99, 29.99),
    (17, 'Metal Detector Kit', 3, 9, 40, 'Silver', 1200, 0.8, 49.99, 69.99),
    (18, 'Art Easel with Supplies', 3, 10, 70, 'Various', 1500, 1.0, 59.99, 79.99),
    (19, 'Robot Building Kit', 3, 11, 55, 'Gray', 500, 0.4, 24.99, 39.99);
INSERT INTO Product (ProductID, ProductName, ProductCategoryID, ProductSubCategoryID, StockLevel, Color, ProductWeightGr, ProductSizeVolM3, ProductCost, ListPrice)
VALUES
    (20, 'Soccer Ball', 4, 12, 90, 'Black/White', 400, 0.4, 14.99, 24.99);
INSERT INTO Product (ProductID, ProductName, ProductCategoryID, ProductSubCategoryID, StockLevel, Color, ProductWeightGr, ProductSizeVolM3, ProductCost, ListPrice)
VALUES
    (21, 'Play-Doh Set', 5, 1, 80, 'Various', 400, 0.5, 12.99, 19.99),
    (22, 'Coloring Book Kit', 5, 2, 70, 'Various', 200, 0.2, 9.99, 14.99),
    (23, 'Toy Telescope', 1, 6, 55, 'Black', 700, 0.7, 29.99, 49.99),
    (24, 'Magic Kit', 1, 7, 40, 'Purple', 500, 0.4, 19.99, 29.99);
INSERT INTO Product (ProductID, ProductName, ProductCategoryID, ProductSubCategoryID, StockLevel, Color, ProductWeightGr, ProductSizeVolM3, ProductCost, ListPrice)
VALUES
    (25, 'Model Rocket Kit', 2, 8, 70, 'Red/White/Blue', 1000, 1.0, 39.99, 59.99),
    (26, 'Paint by Numbers Set', 2, 9, 50, 'Green', 400, 0.3, 14.99, 24.99),
    (27, 'Light-Up Drawing Board', 2, 10, 65, 'Blue', 600, 0.4, 19.99, 34.99),
    (28, 'Building Crane Toy', 3, 11, 85, 'Yellow', 800, 0.6, 34.99, 54.99),
    (29, 'Teddy Bear', 3, 12, 75, 'Brown', 300, 0.2, 12.99, 19.99);
INSERT INTO Product (ProductID, ProductName, ProductCategoryID, ProductSubCategoryID, StockLevel, Color, ProductWeightGr, ProductSizeVolM3, ProductCost, ListPrice)
VALUES
    (30, 'Play Kitchen Set', 2, 7, 80, 'Pink', 1200, 0.8, 39.99, 59.99);

/* Popolamento tabella Sales */
   
-- Vendite in Italia (CountryID = 1)
INSERT INTO Sales (SalesOrderID, SalesOrderLine, OrderDate, ShipDate, ProductID, CityID, CountryID, OrderQuantity, UnitPrice)
VALUES
    ('SO001', 1, '2024-04-01', '2024-04-05', 1, 1, 1, 2, 19.99),
    ('SO001', 2, '2024-04-01', '2024-04-05', 2, 2, 1, 1, 59.99),
    ('SO002', 1, '2024-04-02', '2024-04-06', 3, 3, 1, 3, 24.99),
    ('SO002', 2, '2024-04-02', '2024-04-06', 4, 4, 1, 2, 29.99),
    ('SO003', 1, '2024-04-03', '2024-04-07', 5, 5, 1, 1, 49.99);

-- Vendite negli Stati Uniti (CountryID = 13)
INSERT INTO Sales (SalesOrderID, SalesOrderLine, OrderDate, ShipDate, ProductID, CityID, CountryID, OrderQuantity, UnitPrice)
VALUES
    ('SO004', 1, '2024-04-04', '2024-04-08', 6, 6, 13, 1, 14.99),
    ('SO004', 2, '2024-04-04', '2024-04-08', 7, 7, 13, 1, 39.99),
    ('SO005', 1, '2024-04-05', '2024-04-09', 8, 8, 13, 2, 9.99),
    ('SO005', 2, '2024-04-05', '2024-04-09', 9, 9, 13, 1, 99.99),
    ('SO006', 1, '2024-04-06', '2024-04-10', 10, 10, 13, 1, 19.99);

-- Vendite in Francia (CountryID = 2)
INSERT INTO Sales (SalesOrderID, SalesOrderLine, OrderDate, ShipDate, ProductID, CityID, CountryID, OrderQuantity, UnitPrice)
VALUES
    ('SO007', 1, '2024-04-07', '2024-04-11', 11, 11, 2, 1, 39.99),
    ('SO007', 2, '2024-04-07', '2024-04-11', 12, 12, 2, 1, 29.99),
    ('SO008', 1, '2024-04-08', '2024-04-12', 13, 13, 2, 2, 24.99),
    ('SO008', 2, '2024-04-08', '2024-04-12', 14, 14, 2, 1, 49.99);

-- Vendite nel Regno Unito (CountryID = 5)
INSERT INTO Sales (SalesOrderID, SalesOrderLine, OrderDate, ShipDate, ProductID, CityID, CountryID, OrderQuantity, UnitPrice)
VALUES
    ('SO009', 1, '2024-04-09', '2024-04-13', 15, 15, 5, 1, 54.99),
    ('SO009', 2, '2024-04-09', '2024-04-13', 16, 16, 5, 1, 29.99),
    ('SO010', 1, '2024-04-10', '2024-04-14', 17, 17, 5, 2, 69.99),
    ('SO010', 2, '2024-04-10', '2024-04-14', 18, 18, 5, 1, 79.99);

-- Vendite in Canada (CountryID = 14)
INSERT INTO Sales (SalesOrderID, SalesOrderLine, OrderDate, ShipDate, ProductID, CityID, CountryID, OrderQuantity, UnitPrice)
VALUES
    ('SO011', 1, '2024-04-11', '2024-04-15', 19, 19, 14, 1, 24.99),
    ('SO011', 2, '2024-04-11', '2024-04-15', 20, 20, 14, 1, 24.99),
    ('SO012', 1, '2024-04-12', '2024-04-16', 21, 21, 14, 2, 19.99),
    ('SO012', 2, '2024-04-12', '2024-04-16', 22, 22, 14, 1, 14.99);

   
 /* Esecuzione delle query secondo le richieste:
  * 1. Verificare che i campi definiti come PK siano univoci. 
  * 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
  * 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
  * 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
  * 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? 
  * 	Proponi due approcci risolutivi differenti. 
  * 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
  * */

   

-- query in risposta alla prima domanda
 
	-- City
 select * from City c ;
 select count(*) from City c ;
 -- risultato 106;
 select distinct count(CityID)
 from City c;
-- 106
select count(*) as conteggio_totale
from City c 
group by CityID 
having conteggio_totale > 1
;
-- risultato 0, implica la assenza di valori duplicati nella chiave primaria

	-- Product
select * from Product p ;
 select count(*) from Product p ;
 -- risultato 30;
 select distinct count(ProductID)
 from Product p;
-- risultato 30
select count(*) as conteggio_totale
from Product p  
group by ProductID  
having conteggio_totale > 1
;
-- risultato 0, stessa implicazione precedente

	-- ProductCategory
select * from ProductCategory pc  ;
 select count(*) from ProductCategory pc  ;
 -- risultato 5;
 select distinct count(ProductCategoryID)
 from ProductCategory pc ;
-- risultato 30
select count(*) as conteggio_totale
from ProductCategory pc   
group by ProductCategoryID  
having conteggio_totale > 1
;
-- risultato 0

	-- ProductSubCategory
select * from ProductSubCategory psc  ;
 select count(*) from ProductSubCategory psc  ;
 -- risultato 12;
 select distinct count(ProductSubCategoryID)
 from ProductSubCategory psc ;
-- risultato 12;
select count(*) as conteggio_totale
from ProductSubCategory psc   
group by ProductSubCategoryID  
having conteggio_totale > 1
;
-- risultato totale 0


	-- Region
select * from Region r  ;
 select count(*) from Region r  ;
 -- risultato 20;
 select distinct count(CountryID)
 from Region r ;
-- risultato 20;
select count(*) as conteggio_totale
from Region r   
group by CountryID  
having conteggio_totale > 1
;
-- risultato 0


	-- Sales

select * from Sales s  ;
 select count(*) from Sales s  ;
 -- risultato 22;
 select distinct count(SalesOrderID)
 from Sales s  ;
-- risultato 22;
select count(*) as conteggio_totale
from Sales s   
group by SalesOrderID , SalesOrderLine  
having conteggio_totale > 1
;
-- 0


-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.


select *
from Sales s

select p.ProductID , p.ProductName , sum((s.OrderQuantity * s.UnitPrice)) as  TotalRevenue, year(s.OrderDate) 
from Sales s 
inner join Product p on s.ProductID = p.ProductID
group by p.ProductID , s.OrderDate 
;

 -- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
-- per stato
select r.CountryID , r.CountryName , sum((s.OrderQuantity * s.UnitPrice)) as AnnualRevenue -- , year(s.OrderDate) as SalesYear 
from Sales s 
inner join Region r on s.CountryID = r.CountryID
group by  s.CountryID  
order by sum((s.OrderQuantity * s.UnitPrice)) desc 

-- per anno
select year(s.OrderDate) , sum((s.OrderQuantity * s.UnitPrice)) as AnnualRevenue 
from Sales s 
inner join Region r on s.CountryID = r.CountryID
group by s.OrderDate
order by s.OrderDate  desc 

-- per stato e per anno
select year(s.OrderDate) , r.CountryName , sum((s.OrderQuantity * s.UnitPrice)) as AnnualRevenue
from Sales s 
inner join Region r on s.CountryID = r.CountryID 
group by year(s.OrderDate) , r.CountryID

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

-- tentativo incompleto
select *
from(select sum(s.OrderQuantity) as TotalQuantity , pc.ProductCategoryName 
		from Sales s 
		inner join Product p on s.ProductID = p.ProductID 
		inner join ProductCategory pc on p.ProductCategoryID = pc.ProductCategoryID 
		group by pc.ProductCategoryID  
		) as CatQnt
;
-- query riuscita
select sum(s.OrderQuantity) as TotalQuantity , pc.ProductCategoryName 
		from Sales s 
		inner join Product p on s.ProductID = p.ProductID 
		inner join ProductCategory pc on p.ProductCategoryID = pc.ProductCategoryID 
		group by pc.ProductCategoryID
		order by sum(s.OrderQuantity) desc
		limit 1
;

/* 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? 
   	Proponi due approcci risolutivi differenti.
*/ 

-- 1
select p.ProductID , p.ProductName , p.ProductCategoryID , p.ProductSubCategoryID , p.StockLevel , p.ProductCost 
from Product p  
left join Sales s on p.ProductID = s.ProductID 
where s.SalesOrderID is null
;

-- 2
select p.ProductID , p.ProductName , p.ProductCategoryID , p.ProductSubCategoryID , p.StockLevel , p.ProductCost 
from Product p 
where p.ProductID not in(select ProductID 
							from Sales s )
;


-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select p. ProductID , p.ProductName , max(s.OrderDate) as MaxRecentSaleDate
from Sales s 
inner join Product p on s.ProductID = p.ProductID
group by ProductID , ProductName 
-- order by s.OrderDate desc
;





