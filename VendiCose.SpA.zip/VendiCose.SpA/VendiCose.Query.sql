USE GRIMLI;

-- 1) Ogni qual volta un prodotto viene venduto in un Negozio, qual è la query da eseguire per aggiornare le tabelle di riferimento?

-- Creiamo la tabella con le segnalazioni dei sotto scorta per Store

CREATE TABLE LOG_TABLE (
    LOG_ID INT PRIMARY KEY AUTO_INCREMENT,
    TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    MESSAGE VARCHAR(255)
);

-- Il Drop del trigger per eventuali modifiche
drop trigger check_stock_level;

DELIMITER $$

CREATE TRIGGER check_stock_level
AFTER INSERT ON SALES
FOR EACH ROW
BEGIN
    DECLARE warehouse_quantity INT;
    DECLARE store_quantity INT;
    DECLARE safety_stock_level INT;
    DECLARE diff_quantity INT;

    -- Trova la quantità del prodotto arrivato dal magazzino
    SELECT sum(StoreProductQuantity) into warehouse_quantity
    FROM waretostore
    WHERE PRODUCTID = NEW.PRODUCTID and STOREID = NEW.STOREID;

    -- Trova la quantità del prodotto nel negozio
    SELECT sum(ORDERQUANTITY) INTO store_quantity
    FROM sales
    WHERE PRODUCTID = NEW.PRODUCTID and STOREID = NEW.STOREID;

    -- Trova il livello di sicurezza dello stock per il negozio
    SELECT SAFETYSTOCKLEVEL INTO safety_stock_level
    FROM PRODUCT
    WHERE PRODUCTID = NEW.PRODUCTID;

    -- Calcola la differenza di quantità
    SET diff_quantity = warehouse_quantity- store_quantity ;

    -- Verifica se la differenza è maggiore del livello di sicurezza dello stock
     IF diff_quantity > safety_stock_level THEN
        -- Inserisci un record nella tabella di log con messaggio di avviso
        INSERT INTO LOG_TABLE (MESSAGE) VALUES (concat('Prodotto ',New.Productid,' sotto scorta in negozio ',new.storeid));
    ELSE
        -- Inserisci un record nella tabella di log con messaggio di conferma
        INSERT INTO LOG_TABLE (MESSAGE) VALUES ('Non occorre trasferire');
    END IF;
END$$

DELIMITER ;


  

-- QUERY PER VISIONARE LO STATO DELL'ULTIMO PRODOTTO MOVIMENTATO

SELECT sales.PRODUCTID PRODOTTO,SALES.STOREID AS NEGOZIO,TABLE2.TRASFERIMENTI, sum(ORDERQUANTITY) AS VENDITE,  (TABLE2.TRASFERIMENTI- sum(ORDERQUANTITY)) AS GIACENZE
FROM sales 
JOIN (	SELECT PRODUCTID AS PRODOTTO, sum(StoreProductQuantity) as TRASFERIMENTI, storeid AS NEGOZIO
		FROM waretostore
     	GROUP BY PRODUCTID, NEGOZIO) AS TABLE2
ON TABLE2.PRODOTTO = sales.PRODUCTID
WHERE productid = ( SELECT PRODUCTID AS PRODOTTO
		FROM SALES
		ORDER BY SalesOrderID DESC
		LIMIT 1)
GROUP BY sales.PRODUCTID, SALES.STOREID,TABLE2.TRASFERIMENTI;


-- 2) Quali sono le query da eseguire per verificare quante unità di un prodotto ci sono in un dato magazzino e per monitorare le soglie di restock?

-- Query per calcolare le giacenze di magazzino

SELECT  Table1.Magazzino, P.PRODUCTID AS Prodotto, table1.acquisti AS Acquisti ,table2.trasferimenti as Trasferimenti, (table1.acquisti - table2.trasferimenti) as Giacenze_Magazzino, p.SAFETYSTOCKLEVEL AS STOCK_LEVEL
FROM PRODUCT p
RIGHT join (	select productid as Prodotto, sum(WareOrderQuantity) as Acquisti, warehouseid AS Magazzino
		FROM warehouseorder
        GROUP BY Prodotto, Magazzino
		) as table1
on    p.PRODUCTID=table1.prodotto
RIGHT join (	select productid as Prodotto, sum(StoreProductQuantity) as Trasferimenti
		FROM waretostore
            GROUP BY productid
		) as table2
on    p.PRODUCTID=table2.prodotto
GROUP BY P.PRODUCTID, Table1.Magazzino,table1.acquisti,table2.trasferimenti
ORDER BY Giacenze_Magazzino asc
;

-- Creiamo un log per verificare i sotto scorta:

	-- 1)Procediamo con il creare la tabella con le verifiche per ogni trasferimento da Magazzino
CREATE TABLE LOG_TABLE_Magazzino (
    LOG_ID INT PRIMARY KEY AUTO_INCREMENT,
    TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    MESSAGE VARCHAR(255)
);

	-- 2)Il Drop del trigger per eventuali modifiche
drop trigger check_stock_level_magazzino;

	-- 3)Trigger che aggiorna il log per ogni trasferimento e verifica se il prodotto trasferito è da reintegrare
DELIMITER $$
CREATE TRIGGER check_stock_level_magazzino
AFTER INSERT ON waretostore
FOR EACH ROW
BEGIN
    DECLARE warehouse_quantity INT;
    DECLARE purchase_quantity INT;
    DECLARE safety_stock_level INT;
    DECLARE diff_quantity INT;

    -- Trova la quantità del prodotto prelevata da Magazzino
    SELECT sum(StoreProductQuantity) into warehouse_quantity
    FROM waretostore
    WHERE PRODUCTID = NEW.PRODUCTID and WAREHOUSEID = NEW.WAREHOUSEID;

    -- Trova la quantità del prodotto acquistata per il Magazzino
    SELECT sum(WareOrderQuantity) INTO purchase_quantity 
    FROM warehouseorder
    WHERE PRODUCTID = NEW.PRODUCTID and WAREHOUSEID = NEW.WAREHOUSEID;

    -- Trova il livello di sicurezza dello stock per il negozio
    SELECT SAFETYSTOCKLEVEL INTO safety_stock_level
    FROM PRODUCT
    WHERE PRODUCTID = NEW.PRODUCTID;

    -- Calcola la differenza di quantità
    SET diff_quantity = purchase_quantity-warehouse_quantity  ;

    -- Verifica se la differenza è maggiore del livello di sicurezza dello stock
     IF diff_quantity < safety_stock_level THEN
        -- Inserisci un record nella tabella di log con messaggio di avviso
        INSERT INTO LOG_TABLE_Magazzino (MESSAGE) VALUES (concat('Prodotto ',New.Productid,' in quantità ',diff_quantity,' sotto scorta in Magazzino ',NEW.WAREHOUSEID,' con scorta minima di ',safety_stock_level));
    ELSE
        -- Inserisci un record nella tabella di log con messaggio di conferma
        INSERT INTO LOG_TABLE_Magazzino (MESSAGE) VALUES (concat('Non occorrono Acquisti - Giacenza di ',diff_quantity,' su uno stock di ', safety_stock_level ));
    END IF;
END$$

DELIMITER ;