CREATE DATABASE GIMLI;

USE GIMLI;

CREATE TABLE Category (
             CategoryID INT PRIMARY KEY AUTO_INCREMENT,
             CategoryName VARCHAR(60));
             
CREATE TABLE Product (
			 ProductID INT PRIMARY KEY AUTO_INCREMENT,
             ProductName VARCHAR (60),
             CategoryID INT,
             UnitPrice DECIMAL (10,2),
             SafetyStockLevel MEDIUMINT,
			 FOREIGN KEY(CATEGORYID) REFERENCES CATEGORY (CATEGORYID));

CREATE TABLE Warehouse (
			 WarehouseID INT PRIMARY KEY AUTO_INCREMENT,
             CategoryID INT,
             WarehouseName VARCHAR (60),
             FOREIGN KEY(CATEGORYID) REFERENCES CATEGORY (CATEGORYID));


           
                          
CREATE TABLE Store (
             StoreID INT PRIMARY KEY AUTO_INCREMENT,
			 StoreName varchar(100)); 
             


			
CREATE TABLE WarehouseOrder (
				WareOrderID INT,
                WareOrderLine INT,
				WarehouseID INT,
				ProductID INT,
				WareOrderQuantity MEDIUMINT,
                PRIMARY KEY(WareOrderID, WareOrderLine),
				FOREIGN KEY(WAREHOUSEID) REFERENCES WAREHOUSE (WAREHOUSEID),
				FOREIGN KEY(PRODUCTID) REFERENCES PRODUCT (PRODUCTID));

CREATE TABLE WareToStore (
             TransferID INT,
             TransferLine INT,
             WarehouseID INT,
             ProductID INT,
             StoreProductQuantity MEDIUMINT,
             StoreID INT,
             TransDate DATE,
             PRIMARY KEY(TransferID, TransferLine),
             FOREIGN KEY(STOREID) REFERENCES STORE (STOREID),
             FOREIGN KEY(PRODUCTID) REFERENCES PRODUCT (PRODUCTID),
             FOREIGN KEY(WAREHOUSEID) REFERENCES WAREHOUSE (WAREHOUSEID));
             
           
CREATE TABLE Sales (
             SalesOrderID INT,
             SalesOrderLine INT,
             TransactionDate DATE,
             StoreID INT,
             ProductID INT,
             OrderQuantity MEDIUMINT,
             PRIMARY KEY(SalesOrderID, SalesOrderLine),
		     FOREIGN KEY(STOREID) REFERENCES STORE (STOREID),
             FOREIGN KEY(PRODUCTID) REFERENCES PRODUCT (PRODUCTID));


INSERT INTO Category (CategoryName) VALUES
    ('Elettronica'),
    ('Abbigliamento'),
    ('Alimentari'),
    ('Arredamento'),
    ('Sport'),
    ('Libri'),
    ('Giocattoli'),
    ('Cura della persona'),
    ('Auto e moto'),
    ('Arte e artigianato');
    
    INSERT INTO Product (ProductName, CategoryID, SafetyStockLevel, UnitPrice) VALUES
    ('Smartphone'	,	1	,	30	,	 699.99)	,
    ('Laptop'	,	1	,	100	,	 1099.99)	,
    ('TV LED'	,	1	,	70	,	 599.99)	,
    ('Cuffie Bluetooth'	,	1	,	80	,	 89.99)	,
    ('Fotocamera Mirrorless'	,	1	,	70	,	 799.99)	,
    ('T-Shirt'	,	2	,	20	,	 19.99)	,
    ('Jeans'	,	2	,	80	,	 49.99)	,
    ('Scarpe da ginnastica'	,	2	,	40	,	 79.99)	,
    ('Cappotto invernale'	,	2	,	100	,	 129.99)	,
    ('Cintura di pelle'	,	2	,	40	,	 39.99)	,
    ('Riso basmati'	,	3	,	30	,	 2.99)	,
    ('Pasta integrale'	,	3	,	20	,	 1.99)	,
    ('Latte fresco'	,	3	,	70	,	 1.49)	,
    ('Cioccolato fondente'	,	3	,	90	,	 3.49)	,
    ('Divano in pelle'	,	4	,	50	,	 999.99)	,
    ('Tavolo da pranzo'	,	4	,	60	,	 499.99)	,
    ('Lampada da terra'	,	4	,	40	,	 149.99)	,
    ('Cuscini decorativi'	,	4	,	30	,	 29.99)	,
    ('Tappeto moderno'	,	4	,	60	,	 199.99)	,
    ('Palla da calcio'	,	5	,	30	,	 19.99)	,
    ('Racchetta da tennis'	,	5	,	20	,	 89.99)	,
    ('Materassino yoga'	,	5	,	100	,	 29.99)	,
    ('Bicicletta da corsa'	,	5	,	40	,	 699.99)	,
    ('Pallone da basket'	,	5	,	50	,	 14.99)	,
    ('1984 di George Orwell'	,	6	,	90	,	 12.99)	,
    ('Il signore degli anelli'	,	6	,	30	,	 24.99)	,
    ('Harry Potter e la pietra filosofale'	,	6	,	60	,	 19.99)	,
    ('Cronache del ghiaccio e del fuoco'	,	6	,	60	,	 34.99)	,
    ('Piccole donne'	,	6	,	90	,	 9.99)	,
    ('Lego City'	,	7	,	90	,	 39.99)	,
    ('Barbie Dreamhouse'	,	7	,	10	,	 129.99)	,
    ('Macchinina radiocomandata'	,	7	,	10	,	 49.99)	,
    ('Set da costruzione'	,	7	,	20	,	 24.99)	,
    ('Puzzle 1000 pezzi'	,	7	,	30	,	 14.99)	,
    ('Shampoo antiforfora'	,	8	,	60	,	 6.99)	,
    ('Balsamo idratante'	,	8	,	90	,	 8.99)	,
    ('Crema solare SPF 50'	,	8	,	70	,	 12.99)	,
    ('Deodorante roll-on'	,	8	,	30	,	 4.99)	,
    ('Spazzolino elettrico'	,	8	,	20	,	 29.99)	,
    ('Olio motore sintetico'	,	9	,	40	,	 29.99)	,
    ('Batteria auto'	,	9	,	60	,	 99.99)	,
    ('Cerchi in lega'	,	9	,	100	,	 249.99)	,
    ('Pneumatici estivi'	,	9	,	100	,	 89.99)	,
    ('Copertura per sedili'	,	9	,	100	,	 39.99)	,
    ('Set di pennelli'	,	10	,	20	,	 9.99)	,
    ('Colori ad olio'	,	10	,	40	,	 19.99)	,
    ('Pannelli di tela'	,	10	,	40	,	 14.99)	,
    ('Argilla da modellare'	,	10	,	100	,	 7.99)	,
    ('Macchina da cucire'	,	10	,	50	,	 299.99)	;
    
INSERT INTO Warehouse (CategoryID,WarehouseName) VALUES
    (1,'WARE_Elettronica'),
    (2,'WARE_Abbigliamento'),
    (3,'WARE_Alimentari'),
    (4,'WARE_Arredamento'),
    (5,'WARE_Sport'),
    (6,'WARE_Libri'),
    (7,'WARE_Giocattoli'),
    (8,'WARE_Cura della persona'),
    (9,'WARE_Auto e moto'),
    (10,'WARE_Arte e artigianato');


INSERT INTO Store (StoreName) VALUES
	('Supermercati Epicode'),
    ('Sorriso'),
    ('Maxi'),
    ('Quello che ti serve'),
    ('Prendi quello che vuoi'),
    ('Tutto a un euro');

-- Inserimento di 50 record casuali nella tabella WarehouseOrder utilizzando i valori esistenti

INSERT INTO WarehouseOrder (WareOrderID, WareOrderLine, WarehouseID, ProductID, WareOrderQuantity)
VALUES
    (1, 1, 1, 1, 20),
    (1, 2, 1, 2, 50),
    (1, 3, 1, 3, 30),
    (2, 1, 2, 6, 10),
    (2, 2, 2, 7, 70),
    (3, 1, 3, 11, 40),
    (3, 2, 3, 12, 20),
    (4, 1, 4, 15, 50),
    (4, 2, 4, 16, 60),
    (5, 1, 5, 20, 30),
    (5, 2, 5, 21, 40),
    (6, 1, 6, 26, 90),
    (6, 2, 6, 27, 70),
    (7, 1, 7, 31, 80),
    (7, 2, 7, 32, 100),
    (8, 1, 8, 36, 60),
    (8, 2, 8, 37, 70),
    (9, 1, 9, 41, 40),
    (9, 2, 9, 42, 50),
    (10, 1, 10, 46, 20),
    (10, 2, 10, 47, 30),
    (11, 1, 1, 5, 40),
    (11, 2, 1, 4, 25),
    (12, 1, 2, 8, 15),
    (12, 2, 2, 9, 35),
    (13, 1, 3, 13, 55),
    (13, 2, 3, 14, 45),
    (14, 1, 4, 17, 70),
    (14, 2, 4, 18, 80),
    (15, 1, 5, 24, 35),
    (15, 2, 5, 25, 45),
    (16, 1, 6, 29, 95),
    (16, 2, 6, 30, 75),
    (17, 1, 7, 33, 85),
    (17, 2, 7, 34, 105),
    (18, 1, 8, 38, 65),
    (18, 2, 8, 39, 75),
    (19, 1, 9, 43, 45),
    (19, 2, 9, 44, 55),
    (20, 1, 10, 48, 25),
    (20, 2, 10, 49, 35),
    (21, 1, 1, 10, 30),
    (21, 2, 1, 12, 15),
    (22, 1, 2, 14, 20),
    (22, 2, 2, 16, 40),
    (23, 1, 3, 18, 50),
    (23, 2, 3, 20, 60),
    (24, 1, 4, 22, 25),
    (24, 2, 4, 24, 35),
    (25, 1, 5, 26, 60),
    (25, 2, 5, 28, 80);


INSERT INTO WareToStore (TransferID, TransferLine, WarehouseID, ProductID, StoreProductQuantity, StoreID, TransDate)
VALUES
    (1, 1, 1, 1, 10, 1, '2024-05-01'),
    (1, 2, 1, 2, 20, 1, '2024-05-02'),
    (1, 3, 1, 3, 15, 1, '2024-05-03'),
    (2, 1, 2, 6, 30, 5, '2024-05-04'),
    (2, 2, 2, 7, 25, 5, '2024-05-05'),
    (3, 1, 3, 11, 12, 6, '2024-05-06'),
    (3, 2, 3, 12, 18, 6, '2024-05-07'),
    (4, 1, 4, 15, 50, 3, '2024-05-08'),
    (4, 2, 4, 16, 60, 3, '2024-05-09'),
    (5, 1, 5, 20, 30, 2, '2024-05-10'),
    (5, 2, 5, 21, 40, 2, '2024-05-11');
    
-- Inserimento di 20 record casuali nella tabella Sales
INSERT INTO Sales (SalesOrderID, SalesOrderLine, TransactionDate, StoreID, ProductID, OrderQuantity)
VALUES
    (1, 1, '2023-01-15', 3, 10, 15),
    (2, 1, '2023-02-28', 6, 5, 20),
    (2, 2, '2023-02-28', 6, 8, 10),
    (3, 1, '2023-03-10', 4, 15, 30),
    (3, 2, '2023-03-10', 4, 18, 25),
    (4, 1, '2023-04-05', 2, 4, 12),
    (4, 2, '2023-04-05', 2, 12, 8),
    (5, 1, '2023-05-20', 1, 19, 22),
    (6, 1, '2023-06-02', 5, 7, 18),
    (6, 2, '2023-06-02', 5, 13, 15),
    (7, 1, '2023-07-17', 3, 1, 35),
    (8, 1, '2023-08-08', 4, 9, 28),
    (8, 2, '2023-08-08', 4, 16, 10),
    (9, 1, '2023-09-25', 6, 2, 16),
    (10, 1, '2023-10-12', 2, 11, 20),
    (10, 2, '2023-10-12', 2, 17, 18),
    (11, 1, '2023-11-03', 1, 6, 25),
    (12, 1, '2023-12-19', 5, 3, 30),
    (12, 2, '2023-12-19', 5, 20, 12),
    (13, 1, '2024-01-08', 3, 14, 15);

-- Inserisci gli altri record necessari per un totale di 20
INSERT INTO Sales (SalesOrderID, SalesOrderLine, TransactionDate, StoreID, ProductID, OrderQuantity)
VALUES
    (14, 1, '2024-02-20', 4, 10, 18),
    (14, 2, '2024-02-20', 4, 18, 22),
    (15, 1, '2024-03-15', 6, 5, 30),
    (16, 1, '2024-04-01', 2, 1, 25),
    (17, 1, '2024-05-10', 1, 12, 20),
    (18, 1, '2024-06-05', 5, 9, 15),
    (18, 2, '2024-06-05', 5, 15, 12),
    (19, 1, '2024-07-22', 3, 4, 28),
    (20, 1, '2024-08-18', 4, 7, 22);

-- Visualizza i dati inseriti
SELECT * FROM Sales;

    

select * 
from WaretoStore;
